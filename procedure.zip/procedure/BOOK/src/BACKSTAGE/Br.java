package BACKSTAGE;


public class Br {//������Ϣ��
	private Integer rid;//���߱��
	private String rname;//��������
	private Integer bid;//ͼ����
	private String bname;//����
	private String bdate;//����ʱ��
	private String rdate;//����ʱ��
	private float fun;//����
	public Integer getRid() {
		return rid;
	}
	public void setRid(Integer rid) {
		this.rid = rid;
	}
	public String getRname() {
		return rname;
	}
	public void setRname(String rname) {
		this.rname = rname;
	}
	public Integer getBid() {
		return bid;
	}
	public void setBid(Integer bid) {
		this.bid = bid;
	}
	public String getBname() {
		return bname;
	}
	public void setBname(String bname) {
		this.bname = bname;
	}
	public String getBdate() {
		return bdate;
	}
	public void setBdate(String bdate) {
		this.bdate = bdate;
	}
	public String getRdate() {
		return rdate;
	}
	public void setRdate(String rdate) {
		this.rdate = rdate;
	}
	public float getFun() {
		return fun;
	}
	public void setFun(float fun) {
		this.fun = fun;
	}
	
}