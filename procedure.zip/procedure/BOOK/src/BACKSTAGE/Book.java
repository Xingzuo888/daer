package BACKSTAGE;


public class Book {//����Ϣ��
	private Integer bno;//ͼ����
	private String bname;//ͼ������
	private String bpublish;//ͼ�������
	private String bauthor;//ͼ������
	private float bprice;//ͼ��۸�
	private int bborrow;//ͼ����  0�ѽ�� 1û�н��
	public Integer getBno() {
		return bno;
	}
	public void setBno(Integer bno) {
		this.bno = bno;
	}
	public String getBname() {
		return bname;
	}
	public void setBname(String bname) {
		this.bname = bname;
	}
	public String getBpublish() {
		return bpublish;
	}
	public void setBpublish(String bpublish) {
		this.bpublish = bpublish;
	}
	public String getBauthor() {
		return bauthor;
	}
	public void setBauthor(String bauthor) {
		this.bauthor = bauthor;
	}
	public float getBprice() {
		return bprice;
	}
	public void setBprice(float bprice) {
		this.bprice = bprice;
	}
	public int getBborrow() {
		return bborrow;
	}
	public void setBborrow(int bborrow) {
		this.bborrow = bborrow;
	}
	
}
