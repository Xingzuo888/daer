package BACKSTAGE;

public class Reader {//������Ϣ��
	private Integer rid;//���߱��
	private String rname;//��������
	private String rsex;//�����Ա�
	private int rage;//��������
	private String rjob;//����ְҵ
	private int rnumber;//���߽�����
	private float rcountfun;//���߷���
	public Integer getRid() {
		return rid;
	}
	public void setRid(Integer rid) {
		this.rid = rid;
	}
	public String getRname() {
		return rname;
	}
	public void setRname(String rname) {
		this.rname = rname;
	}
	public String getRsex() {
		return rsex;
	}
	public void setRsex(String rsex) {
		this.rsex = rsex;
	}
	public int getRage() {
		return rage;
	}
	public void setRage(int rage) {
		this.rage = rage;
	}
	public String getRjob() {
		return rjob;
	}
	public void setRjob(String rjob) {
		this.rjob = rjob;
	}
	public int getRnumber() {
		return rnumber;
	}
	public void setRnumber(int rnumber) {
		this.rnumber = rnumber;
	}
	public float getRCountfun() {
		return rcountfun;
	}
	public void setRCountfun(float rcountfun) {
		this.rcountfun = rcountfun;
	}
	
	
}
